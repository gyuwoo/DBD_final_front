/* pages/index.js에서 사용하기 위해 사용되는 파일 */

import MainContainer from "./MainContainer";
export default MainContainer;