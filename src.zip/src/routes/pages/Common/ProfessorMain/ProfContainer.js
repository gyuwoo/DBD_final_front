import React from "react";
import ProfPresenter from "./ProfPresenter";

const ProfContainer = () => {
    // 그래프 데이터
    const barData = {
        labels: ["리더십", "유연성", "책임감", "자기개발", "협동심", "헌신"],
        datasets: [
            {
                label: "전체 학생",
                data: [80, 60, 88, 76, 50, 30],
                backgroundColor: "rgba(75, 192, 192, 0.6)",
            },
            {
                label: "지도 학생",
                data: [62, 60, 70, 88, 76, 50],
                backgroundColor: "rgba(153, 102, 255, 0.6)",
            },
        ],
    };

    const pieData = {
        labels: ["미션 거절율", "미션 보류율", "미션 수락율"],
        datasets: [
            {
                data: [12, 28, 60],
                backgroundColor: ["#ff6384", "#36a2eb", "#ffce56"],
            },
        ],
    };

    // 테이블 데이터
    const tableData = [
        {
            grade: 3,
            studentId: "20201998",
            name: "류은종",
            deferDate: "2024.09.12",
            targetScore: 60,
            level: "높음",
        },
        {
            grade: 3,
            studentId: "20201546",
            name: "경병규",
            deferDate: "2024.09.10",
            targetScore: 45,
            level: "높음",
        },
        {
            grade: 2,
            studentId: "20221189",
            name: "유채림",
            deferDate: "2024.09.08",
            targetScore: 60,
            level: "낮음",
        },
        {
            grade: 2,
            studentId: "20221234",
            name: "김원목",
            deferDate: "2024.09.07",
            targetScore: 50,
            level: "낮음",
        },
    ];

    return (
        <ProfPresenter
            barData={barData}
            pieData={pieData}
            tableData={tableData}
        />
    );
};

export default ProfContainer;
