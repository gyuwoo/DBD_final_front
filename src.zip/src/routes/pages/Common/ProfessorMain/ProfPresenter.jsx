import React from "react";
import { Bar } from "react-chartjs-2";
import ProfNav from "../../../../components/Nav/ProfNav";
import Footer from "../../../../components/Footer/Footer";
import ProfHeader from "../../../../components/Header/ProfHeader";
import "./Prof.css";

const ProfPresenter = ({}) => {
    return (
        <div className="prof-main">
            <ProfHeader />
            <ProfNav />

            <div className="charts-layout">
                <div className="charts-left">
                    <div className="chart-block">
                        <h3>전체 학생 역량 성장 폭</h3>
                    </div>
                    <div className="chart-block">
                        <h3>지도 학생 역량 성장 폭</h3>
                    </div>
                </div>
                <div className="chart-right">
                    <h3>현재 미션 수락률 (2025년 1학기)</h3>
                </div>
            </div>

            <div className="table-student">
                <h3>미션 보류 학생 목록</h3>
            </div>
            
            <Footer />
        </div>
    );
};

export default ProfPresenter;
